import uuid
from typing import Any, Literal, Optional

from controlplane_api.event_types import BILLING_RECORD_CREATED_V1
from controlplane_api.utils import get_logger
from api.domain.serialization import parse_uuid
from api.infrastructure.messaging.tenant_event_publisher import (
    get_tenant_event_publisher,
)
from api.core.exceptions import (BillingRecordException,
                                 BillingRecordNotFoundException)
from api.domain.dtos.billing_dto import (CreatePlanDto,
                                         InvoiceListDto, PlanDto, PlanListDto,
                                         UpdatePlanDto)
from api.domain.entities.stripe_settings import ScopeType
from api.infrastructure.externals.stripe_resolver import StripeResolver
from api.infrastructure.persistence.repositories.billing_record_repository_impl import \
    BillingRecordRepository
from api.infrastructure.persistence.repositories.payment_repository_impl import \
    PaymentRepository

logger = get_logger(__name__)


def _billing_payload_for_event(payload: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in payload.items():
        if isinstance(v, uuid.UUID):
            out[k] = str(v)
        elif isinstance(v, dict):
            out[k] = {
                sk: str(sv) if isinstance(sv, uuid.UUID) else sv
                for sk, sv in v.items()
            }
        else:
            out[k] = v
    return out


class BillingRecordService:
    def __init__(
        self,
        payment_repository: PaymentRepository,
        billing_record_repository: BillingRecordRepository,
        stripe_resolver: StripeResolver,
    ):
        self.payment_repository: PaymentRepository = payment_repository
        self.billing_record_repository: BillingRecordRepository = (
            billing_record_repository
        )
        self.stripe_resolver: StripeResolver = stripe_resolver

    async def _publish_billing_record_created(self, payload: dict[str, Any]) -> None:
        raw_tid = payload.get("tenant_id")
        tid = (
            parse_uuid(raw_tid)
            if raw_tid not in (None, "")
            else None
        )
        await get_tenant_event_publisher().publish(
            tenant_id=tid,
            event_type=BILLING_RECORD_CREATED_V1,
            payload=_billing_payload_for_event(payload),
        )

    # Helper methods
    def _extract_period(
        self, line: dict[str, Any]
    ) -> tuple[Optional[int], Optional[int]]:
        period = line.get("period", {})
        return period.get("start"), period.get("end")

    def _extract_pricing(
        self, line: dict[str, Any]
    ) -> tuple[Optional[str], Optional[str]]:
        pricing = line.get("pricing") or line.get("price")
        if not pricing or not isinstance(pricing, dict):
            return None, None

        # New Stripe format
        details = pricing["price_details"]
        return details.get("price"), details.get("product")

    def _extract_tenant_id(self, line: dict[str, Any], scope: str) -> Optional[str]:
        if scope != "tenant":
            return None

        # Most reliable: line metadata
        tenant_id = line.get("metadata", {}).get("tenant_id")
        if tenant_id:
            return tenant_id

        # Fallback: subscription metadata
        parent = line.get("parent") or {}
        sub_details = parent.get("subscription_details") or {}
        metadata = sub_details.get("metadata") or {}

        if isinstance(metadata, dict):
            return metadata.get("tenant_id")

        return None

    # Helper methods end here

    async def list_plans(self, scope: ScopeType) -> PlanListDto:
        sc = await self.stripe_resolver.get_stripe_client(scope=scope)
        result = await sc.v1.plans.list_async(params={"limit": 100})
        if len(result.data) == 0:
            return PlanListDto(plans=[], has_more=False)
        return PlanListDto(
            plans=[plan for plan in result.data], has_more=result.has_more
        )

    async def create_plan(self, new_plan: CreatePlanDto, scope: ScopeType) -> None:
        try:
            sc = await self.stripe_resolver.get_stripe_client(scope=scope)
            await sc.v1.plans.create_async(
                params={
                    "amount": new_plan.amount,
                    "interval": new_plan.interval,
                    "currency": new_plan.currency,
                    "product": new_plan.product_id,
                }
            )
        except Exception as e:
            logger.error(f"Error creating plan : {e}")
            raise BillingRecordException(str(e))

    async def update_plan(
        self, plan_id: str, update_plan: UpdatePlanDto, scope: ScopeType
    ) -> None:
        try:
            sc = await self.stripe_resolver.get_stripe_client(scope=scope)
            await sc.v1.plans.update_async(
                plan=plan_id,
                params={
                    "active": update_plan.active,
                    "trial_period_days": update_plan.trial_period_days,
                    "metadata": update_plan.metadata or {},
                },
            )
        except Exception as e:
            logger.error(f"Error updating plan {plan_id}: {e}")
            raise BillingRecordNotFoundException(plan_id)

    async def get_plan(self, plan_id: str, scope: ScopeType) -> PlanDto:
        try:
            sc = await self.stripe_resolver.get_stripe_client(scope=scope)
            return await sc.v1.plans.retrieve_async(plan=plan_id)
        except Exception as e:
            logger.error(f"Error retrieving plan {plan_id}: {e}")
            raise BillingRecordNotFoundException(plan_id)

    async def delete_plan(self, plan_id: str, scope: ScopeType) -> None:
        sc = await self.stripe_resolver.get_stripe_client(scope=scope)
        result = await sc.v1.plans.delete_async(plan=plan_id)
        if result.deleted is False:
            raise BillingRecordException(f"Unable to delete the plan {plan_id}.")

    async def list_invoices(self, scope: ScopeType) -> InvoiceListDto:
        sc = await self.stripe_resolver.get_stripe_client(scope=scope)
        result = await sc.v1.invoices.list_async(params={"limit": 100})
        return InvoiceListDto(
            invoices=[invoice for invoice in result.data], has_more=result.has_more
        )

    async def from_stripe_invoice_paid(
        self,
        invoice: dict[str, Any],
        scope: Literal["tenant", "host"],
        tenant_id: Optional[str] = None,
    ) -> Optional[dict[str, Any]]:
        """
        Converts a Stripe `invoice.paid` event into a row payload for billing_records.
        Returns None if not applicable (e.g. no subscription).
        """
        # Extract first line item (99.9% of cases there's only one)
        lines = invoice.get("lines", {}).get("data", [])
        if not lines:
            return None

        line = lines[0]

        period_start, period_end = self._extract_period(line)
        price_id, product_id = self._extract_pricing(line)
        tenant_id = tenant_id or self._extract_tenant_id(line, scope)

        sub_raw = invoice.get("subscription")
        if isinstance(sub_raw, dict):
            stripe_sub_id = sub_raw.get("id")
        else:
            stripe_sub_id = sub_raw

        return {
            "scope": scope,
            "actor": "tenant" if tenant_id else "end_user",
            "tenant_id": tenant_id,
            "user_id": None,
            "payment_type": "card",
            "currency": invoice["currency"].upper(),
            "amount": invoice["amount_paid"],
            "stripe_customer_id": invoice["customer"],
            "stripe_subscription_id": stripe_sub_id,
            "stripe_session_id": None,
            "product_id": product_id,
            "price_id": price_id,
            "status": invoice["status"],
            "current_period_end": period_end,
            "canceled_at": None,
            "cancellation_reason": None,
            "metadata": {
                "invoice_id": invoice["id"],
                "stripe_event_id": invoice["id"],
                "billing_reason": invoice.get("billing_reason"),
                "hosted_invoice_url": invoice.get("hosted_invoice_url"),
                "invoice_pdf": invoice.get("invoice_pdf"),
                "period_start": str(period_start),
                "period_end": str(period_end),
            },
        }

    async def create_billing_record(self, billing_record: dict[str, Any]) -> None:
        """
        Create a billing record in the database
        """
        await self.billing_record_repository.create(billing_record)
        await self._publish_billing_record_created(billing_record)
