"""Shared identity interfaces."""
